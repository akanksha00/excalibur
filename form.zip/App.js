import React, { useState } from "react";
import "./App.css";

export default function App() {
  const [state, setState] = useState({
    url: "",
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setState((prevProps) => ({
      ...prevProps,
      [name]: value
    }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(state);
  };

  return (
    <div className="App">
      <h1>Time Stamp Generator</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-control">
          {/* <label>Enter youtube link</label> */}
          <input
            type="text"
            name="url"
            placeholder="Enter youtube link"
            value={state.url}
            onChange={handleInputChange}
          />
        </div>
        <div className="form-control">
          <button >Generate</button>
        </div>
      </form>
    </div>
  );
}